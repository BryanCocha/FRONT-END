const newUID = (): string => Math.random().toString(36).slice(2)

class Product {
    codigo : string;
    nombre: string;
    marca: string;
    precio: number;
    monto: number;
    total: number;

    constructor(codigo: string, nombre: string, marca: string, precio: number, monto:number){
        this.codigo = codigo;
        this.nombre = nombre;
        this.marca = marca;
        this.precio = precio;
        this.monto = monto;
        this.total= this.precio*this.monto;
        }
}



class Factura {
    productos : Array<Product> = [];  
    subtotal: number;
    total: number;

    
    constructor(){
        this.productos = [];
        this.subtotal = 0;
        this.total = 0;

        }
    agregarNuevoProducto(articulos : Product){
        this.subtotal += articulos.precio * articulos.monto;
        this.total = this.subtotal + (this.subtotal*0.12);
        this.productos.push(articulos);
    }
}



var articulos = new Product(`${newUID()}`,'reloj','rolex',800,1);
var articulos2 = new Product(`${newUID()}`, 'carro','mazda',15000,1);
var articulos3 = new Product(`${newUID()}`, 'moto','mitsubishi',2000,1)
//console.log(p);
var f = new Factura();
f.agregarNuevoProducto(articulos);
f.agregarNuevoProducto(articulos2);
f.agregarNuevoProducto(articulos3);
console.log(f);